def simple_function(text: str) -> str:
    return text
